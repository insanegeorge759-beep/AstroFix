package com.astrofix.chunk;

import com.astrofix.AstroFixMod;
import java.util.concurrent.*;

public class AstroChunkSystem {

    private static ExecutorService executor;
    private static final PriorityBlockingQueue<ChunkTask> queue = new PriorityBlockingQueue<>();

    public static void init() {
        int threads = Math.max(1, Runtime.getRuntime().availableProcessors() - 1);
        executor = Executors.newFixedThreadPool(threads, r -> {
            Thread t = new Thread(r, "AstroFix-Chunk-" + threads);
            t.setDaemon(true);
            t.setPriority(Thread.NORM_PRIORITY - 1);
            return t;
        });
        AstroFixMod.LOGGER.info("[AstroFix] Chunk System: {} thread(s) ჩართულია", threads);
    }

    public static void scheduleChunk(int x, int z, int priority) {
        queue.offer(new ChunkTask(x, z, priority));
    }

    public static boolean isNearPlayer(int cx, int cz, int px, int pz, int radius) {
        return Math.abs(cx - px) <= radius && Math.abs(cz - pz) <= radius;
    }

    public static void shutdown() {
        if (executor != null) executor.shutdown();
    }

    public static class ChunkTask implements Comparable<ChunkTask> {
        public final int x, z, priority;
        public ChunkTask(int x, int z, int priority) {
            this.x = x; this.z = z; this.priority = priority;
        }
        @Override public int compareTo(ChunkTask o) {
            return Integer.compare(this.priority, o.priority);
        }
    }
}
