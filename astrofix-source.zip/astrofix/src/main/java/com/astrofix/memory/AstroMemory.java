package com.astrofix.memory;

import com.astrofix.AstroFixMod;

public class AstroMemory {

    private static final long GC_THRESHOLD_MB = 50;
    private static long lastGcTime = 0;
    private static final long GC_COOLDOWN_MS = 30000; // 30 წამი

    public static void init() {
        Runtime rt = Runtime.getRuntime();
        rt.gc();
        long free = rt.freeMemory() / 1024 / 1024;
        long total = rt.totalMemory() / 1024 / 1024;
        long max = rt.maxMemory() / 1024 / 1024;
        AstroFixMod.LOGGER.info("[AstroFix] Memory: {}MB free / {}MB total / {}MB max", free, total, max);
        AstroFixMod.LOGGER.info("[AstroFix] Memory Optimizer: ჩართულია (threshold: {}MB)", GC_THRESHOLD_MB);
    }

    public static void tick() {
        Runtime rt = Runtime.getRuntime();
        long freeMB = rt.freeMemory() / 1024 / 1024;
        long now = System.currentTimeMillis();

        if (freeMB < GC_THRESHOLD_MB && (now - lastGcTime) > GC_COOLDOWN_MS) {
            rt.gc();
            lastGcTime = now;
            AstroFixMod.LOGGER.debug("[AstroFix] GC გაეშვა - freed {}MB",
                (rt.freeMemory() / 1024 / 1024) - freeMB);
        }
    }

    public static long getUsedMemoryMB() {
        Runtime rt = Runtime.getRuntime();
        return (rt.totalMemory() - rt.freeMemory()) / 1024 / 1024;
    }

    public static int getMemoryPercent() {
        Runtime rt = Runtime.getRuntime();
        long used = rt.totalMemory() - rt.freeMemory();
        return (int)((used * 100) / rt.maxMemory());
    }
}
