package com.astrofix.redstone;

import com.astrofix.AstroFixMod;
import java.util.*;

public class AstroRedstone {

    private static final int MAX_UPDATES_PER_TICK = 256;
    private static int updatesThisTick = 0;
    private static final Set<Long> processedPositions = new HashSet<>();

    public static void init() {
        AstroFixMod.LOGGER.info("[AstroFix] Anti Redstone Lag: max {}/tick ჩართულია", MAX_UPDATES_PER_TICK);
    }

    public static void onTickStart() {
        updatesThisTick = 0;
        processedPositions.clear();
    }

    // Alternate Current-ის მსგავსი — დუბლიკატი update-ების skip
    public static boolean shouldProcessUpdate(int x, int y, int z) {
        if (updatesThisTick >= MAX_UPDATES_PER_TICK) return false;

        long key = ((long)(x & 0x3FFFFFF) | ((long)(z & 0x3FFFFFF) << 26) | ((long)(y & 0xFF) << 52));
        if (processedPositions.contains(key)) return false;

        processedPositions.add(key);
        updatesThisTick++;
        return true;
    }

    public static boolean isOverloaded() {
        return updatesThisTick >= MAX_UPDATES_PER_TICK;
    }

    public static int getUpdatesThisTick() {
        return updatesThisTick;
    }
}
