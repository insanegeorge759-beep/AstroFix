package com.astrofix.render;

import com.astrofix.AstroFixMod;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.MathHelper;

public class AstroRenderer {

    private static float[] frustumPlanes = new float[24];
    private static boolean frustumReady = false;

    public static void init() {
        AstroFixMod.LOGGER.info("[AstroFix] AstroRenderer: Frustum + Occlusion + LOD + Batch ჩართულია");
    }

    // Frustum Culling — კამერის გარეთ = skip
    public static boolean isInFrustum(double x, double y, double z, double radius) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null || client.player == null) return true;

        Vec3d cam = client.player.getEyePos();
        float fov = client.options.getFov().getValue();
        float yaw = client.player.getYaw();
        float pitch = client.player.getPitch();

        double dx = x - cam.x;
        double dy = y - cam.y;
        double dz = z - cam.z;
        double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);

        if (dist == 0) return true;

        // კამერის მიმართულება
        double camDirX = -MathHelper.sin(yaw * 0.017453292f) * MathHelper.cos(pitch * 0.017453292f);
        double camDirY = -MathHelper.sin(pitch * 0.017453292f);
        double camDirZ = MathHelper.cos(yaw * 0.017453292f) * MathHelper.cos(pitch * 0.017453292f);

        double dot = (dx / dist) * camDirX + (dy / dist) * camDirY + (dz / dist) * camDirZ;
        double halfFov = Math.toRadians(fov / 2.0 + 10.0);

        return dot > Math.cos(halfFov) || dist < radius + 2.0;
    }

    // LOD System — შორს = ნაკლები დეტალი
    public static int getLODLevel(double distance) {
        if (distance < 16) return 0;  // სრული ხარისხი
        if (distance < 32) return 1;  // საშუალო
        if (distance < 48) return 2;  // დაბალი
        return 3;                      // მინიმალური
    }

    // Stutter Fix — chunk load-ზე frame spike-ების შემცირება
    public static boolean shouldDeferChunkBuild(int pendingBuilds) {
        return pendingBuilds > 8;
    }

    // Draw call batching threshold
    public static int getMaxBatchSize() {
        return 512;
    }
}
