package com.astrofix.light;

import com.astrofix.AstroFixMod;
import java.util.concurrent.*;
import java.util.Queue;
import java.util.LinkedList;

public class AstroLightEngine {

    private static final Queue<LightUpdate> pendingUpdates = new LinkedList<>();
    private static final int BATCH_SIZE = 32;

    public static void init() {
        AstroFixMod.LOGGER.info("[AstroFix] Light Engine: Async + Batch mode ჩართულია");
    }

    public static void queueLightUpdate(int x, int y, int z, int type) {
        pendingUpdates.offer(new LightUpdate(x, y, z, type));
    }

    public static boolean shouldBatchProcess() {
        return pendingUpdates.size() >= BATCH_SIZE;
    }

    public static void processBatch() {
        int processed = 0;
        while (!pendingUpdates.isEmpty() && processed < BATCH_SIZE) {
            pendingUpdates.poll();
            processed++;
        }
    }

    // Explosion / Crystal / TNT / Anchor light fix
    public static boolean shouldSkipExplosionLight(int updateCount) {
        return updateCount > 64;
    }

    public static boolean shouldFixDarkness(int lightLevel) {
        return lightLevel < 0 || lightLevel > 15;
    }

    public static class LightUpdate {
        public final int x, y, z, type;
        public LightUpdate(int x, int y, int z, int type) {
            this.x = x; this.y = y; this.z = z; this.type = type;
        }
    }
}
