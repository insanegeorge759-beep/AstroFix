package com.astrofix.mixin.culling;

import com.astrofix.culling.AstroCullingSystem;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(EntityRenderer.class)
public class EntityRendererMixin<T extends Entity> {

    @Inject(method = "shouldRender", at = @At("HEAD"), cancellable = true)
    private void onShouldRender(T entity, net.minecraft.client.frustum.Frustum frustum,
                                 double x, double y, double z,
                                 CallbackInfoReturnable<Boolean> cir) {
        if (entity instanceof ItemEntity itemEntity) {
            if (!AstroCullingSystem.shouldRenderItem(itemEntity)) {
                cir.setReturnValue(false);
                return;
            }
        }

        if (!AstroCullingSystem.shouldRenderEntity(entity)) {
            cir.setReturnValue(false);
        }
    }
}
