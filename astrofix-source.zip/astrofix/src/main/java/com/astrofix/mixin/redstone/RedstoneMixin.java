package com.astrofix.mixin.redstone;

import com.astrofix.redstone.AstroRedstone;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(World.class)
public class RedstoneMixin {

    @Inject(method = "tickBlockEntities", at = @At("HEAD"))
    private void onTickStart(CallbackInfo ci) {
        AstroRedstone.onTickStart();
    }
}
