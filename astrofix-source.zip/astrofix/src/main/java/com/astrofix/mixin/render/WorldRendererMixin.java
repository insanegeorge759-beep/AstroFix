package com.astrofix.mixin.render;

import com.astrofix.render.AstroRenderer;
import net.minecraft.client.render.WorldRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(WorldRenderer.class)
public class WorldRendererMixin {

    @Inject(method = "reload", at = @At("HEAD"))
    private void onReload(CallbackInfo ci) {
        // AstroFix stutter fix on reload
    }
}
