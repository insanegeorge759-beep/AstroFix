package com.astrofix.explosion;

import com.astrofix.AstroFixMod;

public class ExplosionOptimizer {

    private static int activeExplosions = 0;
    private static final int MAX_PARTICLES_PER_EXPLOSION = 8;
    private static final int MAX_SIMULTANEOUS_EXPLOSIONS = 20;
    private static final double MAX_RENDER_DISTANCE = 32.0;

    public static void init() {
        AstroFixMod.LOGGER.info("[AstroFix] Explosion NoLag: ჩართულია (max {} simultaneous)", MAX_SIMULTANEOUS_EXPLOSIONS);
    }

    public static void onExplosionStart() {
        activeExplosions++;
    }

    public static void onExplosionEnd() {
        if (activeExplosions > 0) activeExplosions--;
    }

    // 1000 TNT-ზე particles-ს ამცირებს
    public static int getLimitedParticleCount(int original) {
        if (activeExplosions > MAX_SIMULTANEOUS_EXPLOSIONS) return 0;
        if (activeExplosions > 10) return Math.min(original, MAX_PARTICLES_PER_EXPLOSION);
        return original;
    }

    // შორს მყოფი explosion არ რენდერდება
    public static boolean shouldRenderExplosion(double distance) {
        return distance <= MAX_RENDER_DISTANCE;
    }

    // 1000 TNT-ზე effects-ს გამორთავს
    public static boolean shouldSkipEffects() {
        return activeExplosions > MAX_SIMULTANEOUS_EXPLOSIONS;
    }

    public static int getActiveExplosions() {
        return activeExplosions;
    }
}
