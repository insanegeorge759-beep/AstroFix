package com.astrofix;

import com.astrofix.chunk.AstroChunkSystem;
import com.astrofix.explosion.ExplosionOptimizer;
import com.astrofix.light.AstroLightEngine;
import com.astrofix.memory.AstroMemory;
import com.astrofix.redstone.AstroRedstone;
import com.astrofix.render.AstroRenderer;
import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AstroFixMod implements ModInitializer {

    public static final String MOD_ID = "astrofix";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("========================================");
        LOGGER.info("  AstroFix 1.0.0 | MC 1.21.11 Loading ");
        LOGGER.info("========================================");

        AstroChunkSystem.init();
        AstroLightEngine.init();
        ExplosionOptimizer.init();
        AstroMemory.init();
        AstroRedstone.init();
        AstroRenderer.init();

        LOGGER.info("[AstroFix] ყველა სისტემა ჩართულია!");
    }
}
