package com.astrofix.culling;

import com.astrofix.AstroFixMod;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

public class AstroCullingSystem {

    private static final double ITEM_CULL_DISTANCE = 5.0;
    private static final double ENTITY_CULL_DISTANCE = 64.0;

    public static void init() {
        AstroFixMod.LOGGER.info("[AstroFix] Culling System: Entity + Item + Occlusion ჩართულია");
    }

    // Entity Culling — კედლის იქით არ რენდერდება
    public static boolean shouldRenderEntity(Entity entity) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null || client.player == null) return true;

        // Player ყოველთვის რენდერდება
        if (entity instanceof PlayerEntity) return true;

        Vec3d entityPos = entity.getPos();
        Vec3d playerPos = client.player.getPos();
        double distance = entityPos.distanceTo(playerPos);

        // ძალიან შორს = არ რენდერდება
        if (distance > ENTITY_CULL_DISTANCE) return false;

        // 2 block-ზე ახლოს = ყოველთვის რენდერდება
        if (distance < 2.0) return true;

        // კედლის შემოწმება
        return !isOccluded(entityPos, playerPos, client);
    }

    // Item Culling — 5 block-ზე შორს dropped items არ რენდერდება
    public static boolean shouldRenderItem(ItemEntity item) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null || client.player == null) return true;

        double distance = item.getPos().distanceTo(client.player.getPos());
        return distance <= ITEM_CULL_DISTANCE;
    }

    // Occlusion Check
    private static boolean isOccluded(Vec3d entityPos, Vec3d playerPos, MinecraftClient client) {
        if (client.world == null) return false;

        double dx = entityPos.x - playerPos.x;
        double dy = entityPos.y - playerPos.y;
        double dz = entityPos.z - playerPos.z;
        int steps = (int) Math.max(Math.max(Math.abs(dx), Math.abs(dy)), Math.abs(dz));

        if (steps == 0) return false;

        for (int i = 1; i < steps; i++) {
            float t = (float) i / steps;
            BlockPos check = new BlockPos(
                (int)(playerPos.x + dx * t),
                (int)(playerPos.y + dy * t),
                (int)(playerPos.z + dz * t)
            );
            if (client.world.getBlockState(check).isOpaque()) return true;
        }
        return false;
    }
}
